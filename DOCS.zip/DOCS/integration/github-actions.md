# GitHub Actions Integration Guide

Integrating Anchor into your GitHub Actions workflow ensures that compliance audits run automatically on every Pull Request. It blocks changes that introduce severe security or policy violations.

---

## 📋 The Automated Flow

```
Developer pushes code / opens PR
         ↓
GitHub Actions runner checks out code
         ↓
Installs anchor-audit via pip
         ↓
Downloads the latest constitution.anchor
         ↓
Runs "anchor check" over staged files
         ↓
Pass (merge allowed) OR Fail (merge blocked)
```

---

## 🛠️ Configuration Template

Create a new file named `.github/workflows/anchor.yml` in your repository:

```yaml
name: Anchor Governance Guardrail

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]

jobs:
  governance-scan:
    name: Run Compliance Scan
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4
        with:
          fetch-depth: 0 # Required for architectural drift analysis (git history)

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Cache PIP Dependencies
        uses: actions/cache@v4
        with:
          path: ~/.cache/pip
          key: ${{ runner.os }}-pip-${{ hashFiles('**/requirements.txt') }}
          restore-keys: |
            ${{ runner.os }}-pip-

      - name: Install Anchor
        run: |
          pip install --upgrade pip
          pip install anchor-audit

      - name: Run Anchor Static Check
        # Scans modified files, fails on 'error' or 'blocker' violations
        run: |
          anchor check . --severity error --json-report

      - name: Upload Compliance Artifacts
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: anchor-compliance-report
          path: |
            .anchor/reports/governance_report.html
            .anchor/telemetry/governance_report.json
```

---

## 💡 Advanced Features

### 1. Generating GitHub Step Summaries
To output a clean compliance dashboard directly inside the GitHub Actions run window, use the `--github-summary` flag:

```yaml
      - name: Run Anchor Check with Summary
        run: |
          anchor check . --github-summary
```

This creates an `anchor-summary.md` file and appends it to the workflow's job summary output.

### 2. Scanning PR Staged Files Only
To keep scans fast, you can restrict the static checker to process only files modified in the pull request:

```yaml
      - name: Get Changed Files
        id: changed-files
        run: |
          echo "files=$(git diff --name-only origin/main...HEAD | grep -E '\.(py|ts|tsx)$' | tr '\n' ' ')" >> $GITHUB_OUTPUT

      - name: Scan Changed Files Only
        if: steps.changed-files.outputs.files != ''
        run: |
          anchor check ${{ steps.changed-files.outputs.files }} --severity error
```
