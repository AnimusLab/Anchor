# Supported Rules Directory

Anchor provides structured policy rules across nine core governance domains. Below is the directory of the most common active rulesets in `constitution.anchor` and their mitigation patterns.

---

## 🛡️ Security Domain (`SEC-` Namespace)

Governs prompt injection, credential leaks, shell execution, model tampering, and execution safety.

| Rule ID | Name | Default Severity | Description / Trigger | Mitigation Action |
|---|---|---|---|---|
| **`SEC-001`** | Prompt Injection | `blocker` | Detects jailbreaks or instruction bypass strings (e.g. `ignore previous instructions`, `DAN`). | Filter user prompts; employ strict system guidelines. |
| **`SEC-004`** | Credential Harvesting | `blocker` | Detects raw namespace hooks like `os.environ` accessing keys. | Access keys via secure configuration vaults (`config.get_key()`). |
| **`SEC-006`** | Raw Network Access | `error` | Outbound external connection bypasses local governed enclaves. | Route connection through proxy gateway endpoints. |
| **`SEC-007`** | Shell Injection | `blocker` | Executes subshell code built from dynamic user/model inputs (`os.system`). | Refactor to `subprocess.run` with array arguments and `shell=False`. |
| **`SEC-009`** | SQL Injection | `blocker` | Raw string concatenation on database statements. | Refactor to parameterized queries or ORM models. |
| **`SEC-010`** | Unsafe Execution | `blocker` | Dynamic code execution calls (`eval()`, `exec()`). | Refactor to static logic or execute in the isolated Diamond Cage. |

---

## ⚖️ Ethics Domain (`ETH-` Namespace)

Governs proxy bias, transparency metrics, explainability obligations, and agent empathy levels.

| Rule ID | Name | Default Severity | Description / Trigger | Mitigation Action |
|---|---|---|---|---|
| **`ETH-001`** | Proxy Classification | `error` | Scans prompt strings for demographic attributes causing proxy bias. | Use anonymized user IDs or strip attributes before prompt compilation. |
| **`ETH-002`** | Explainability Check | `error` | Checks whether the agent records reasoning paths for decision audits. | Require the agent's completion to output a `reasoning_path` key. |
| **`ETH-004`** | Prohibited Proxies | `blocker` | Scans for banned correlation features (e.g. ZIP code proxies for credit risk). | Redact proxy attributes in pre-processing layers. |

---

## 🔒 Privacy Domain (`PRV-` Namespace)

Governs data sovereignty, PII leakage, and log sanitation.

| Rule ID | Name | Default Severity | Description / Trigger | Mitigation Action |
|---|---|---|---|---|
| **`PRV-001`** | PII Leakage | `blocker` | Outbound prompts containing Social Security Numbers, emails, or names. | Integrate an anonymizer wrapper (e.g., Presidio) to mask PII tokens. |
| **`PRV-003`** | Sovereignty Boundary | `error` | Transferring datasets across geo-restricted hubs (e.g., EU data leaving EU VPC). | Bind routes to local Spoke nodes in the same region. |

---

## 🤖 Agentic Domain (`AGT-` Namespace)

Governs cross-agent trust, autonomous tool invocation, and recursive loop boundaries.

| Rule ID | Name | Default Severity | Description / Trigger | Mitigation Action |
|---|---|---|---|---|
| **`AGT-001`** | Tool Overreach | `blocker` | An agent invokes unauthorized API tools without a confirmation gate. | Implement a human-in-the-loop callback for high-risk tools. |
| **`AGT-003`** | Loop Recursion Bounded | `error` | Infinite loops where agents invoke each other repeatedly, draining tokens. | Bind session executions to a strict maximum iteration timeout (e.g., max 10 calls). |

---

## 📦 Supply Chain Domain (`SUP-` Namespace)

Governs code dependencies, package versions, and model weight provenance.

| Rule ID | Name | Default Severity | Description / Trigger | Mitigation Action |
|---|---|---|---|---|
| **`SUP-001`** | Model Hash Mismatch | `blocker` | Training weight hashes (e.g. safetensors) mismatch authorized manifests. | Use cryptographically sealed, signed model versions. |
| **`SUP-003`** | Unvetted Dependency | `error` | Importing unverified third-party libraries. | Pin dependencies to verified hashes in `requirements.txt`. |
